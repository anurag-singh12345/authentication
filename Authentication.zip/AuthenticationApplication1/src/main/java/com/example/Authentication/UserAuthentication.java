package com.example.Authentication;

public class UserAuthentication {

    // Dummy user credentials (replace with actual authentication logic)
    private static final String VALID_USERNAME = "user123";
    private static final String VALID_PASSWORD = "password123";

    /**
     * Authenticates a user with the given username and password.
     *
     * @param username The username to authenticate.
     * @param password The password to authenticate.
     * @return True if authentication is successful, false otherwise.
     */
    public static boolean authenticate(String username, String password) {
        // Replace this with your actual authentication logic (e.g., database check)
        return VALID_USERNAME.equals(username) && VALID_PASSWORD.equals(password);
    }

    /**
     * Checks if a given username is valid (exists in the system).
     *
     * @param username The username to check.
     * @return True if the username is valid, false otherwise.
     */
    public static boolean isValidUsername(String username) {
        // Replace this with your actual logic to check if the username exists
        return VALID_USERNAME.equals(username);
    }

    /**
     * Checks if a given password is valid for a specific user.
     *
     * @param username The username associated with the password.
     * @param password The password to check.
     * @return True if the password is valid, false otherwise.
     */
    public static boolean isValidPassword(String username, String password) {
        // Replace this with your actual logic to check if the password is valid
        return VALID_USERNAME.equals(username) && VALID_PASSWORD.equals(password);
    }
}