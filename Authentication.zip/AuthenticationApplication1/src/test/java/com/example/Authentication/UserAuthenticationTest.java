package com.example.Authentication;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class UserAuthenticationTest {

    @Test
    void testAuthenticateValidCredentials() {
        assertTrue(UserAuthentication.authenticate("user123", "password123"));
    }

    @Test
    void testAuthenticateInvalidCredentials() {
        assertFalse(UserAuthentication.authenticate("invalidUser", "invalidPassword"));
    }

    @Test
    void testIsValidUsernameValid() {
        assertTrue(UserAuthentication.isValidUsername("user123"));
    }

    @Test
    void testIsValidUsernameInvalid() {
        assertFalse(UserAuthentication.isValidUsername("invalidUser"));
    }

    @Test
    void testIsValidPasswordValid() {
        assertTrue(UserAuthentication.isValidPassword("user123", "password123"));
    }

    @Test
    void testIsValidPasswordInvalid() {
        assertFalse(UserAuthentication.isValidPassword("user123", "invalidPassword"));
    }
}